<!doctype html>
	<?php
	require "con.php"
	?>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href='https://fonts.googleapis.com/css?family=Jaldi:400,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="css/reset.css"> <!-- CSS reset -->
	<link rel="stylesheet" href="css/style.css"> <!-- Resource style -->
	<script src="js/modernizr.js"></script> <!-- Modernizr -->
  	
	<title>Products Registration</title>
	<style>
		
	</style>
</head>
<body>
	<h1>Product Registration</h1>
<div>
	<div style="float: left;">
	<form>
		<table>
			<tr><td>Product ID</td><td><input type="text" placeholder="Enter Product ID" name="p_id"></td></tr>
			<tr><td>Product Name</td><td><input type="text" placeholder="Enter Product Name" name="p_id"></td></tr>
			<tr><td>Supplier ID</td><td><input type="text" placeholder="Enter Supplier ID" name="p_id"></td></tr>
			<tr><td>Supplier Name<td><input type="text" placeholder="Supplier Name" name="p_id"></td></tr>
			<tr>
				<td>Class</td><td>
			<select>
				<option></option>
								<?php
				$sql = "SELECT class_name FROM classes";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<option>" . $row["class_name"]. "</option>";
    }
} else {
    echo "0 results";
}

				?>
			</select>
				</td>
			</tr>
			<tr>
				<td>Group</td><td>
			<select>
				<option></option>
								<?php
				$sql = "SELECT group_name FROM groups";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<option>" . $row["group_name"]. "</option>";
    }
} else {
    echo "0 results";
}
				?>
			</select>
				</td>
			</tr>
			<tr>
				<td>Sub-Group</td><td>
			<select>
				<option></option>
								<?php
				$sql = "SELECT sub_group_name FROM sub_groups";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<option>" . $row["sub_group_name"]. "</option>";
    }
} else {
    echo "0 results";
}

				?>
			</select>
				</td>
			</tr>
	<tr><td>Quantity<td><input type="text" placeholder="Enter Quantity" name="qty"></td></tr>
	<tr><td>PRICE<td><input type="text" placeholder="Enter Selling Price" name="s_price"></td></tr>
	<tr><td><td><input type="submit" value="Enter"><input type="reset" value="Clear"></td></tr>
		</table>
		
	</form>
	</div>
	<div style="float: left;">
	<table class="data_table">
		<tr><td>PRODUCT ID</td><td>NAME</td><td>QUANTITY</td><td>SUPPLIER ID</td><td>CLASS</td><td>PRICE</td></tr>
					<?php
				$sql = "SELECT * FROM products";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["product_id"]. "</td><td>".$row["product_name"]."</td><td>".$row["quantity"]."</td><td>".$row["supplier_id"]."</td><td>".$row["class"]."</td><td>".$row["selling_price"]."</td></tr>";
    }
} else {
    echo "0 results";
}
$conn->close();
				?>
	</table>
	</div>
</div>
<script src="js/jquery-2.1.4.js"></script>
<script src="js/main.js"></script> <!-- Resource jQuery -->
</body>
</html>